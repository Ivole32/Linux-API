# Linux-API
A linux API server to get system informations and other live informations about your linux machine.